#BasicService.vm
#make Service templete
import json
import utils.config
import threading
import utils.json_constant	
from flask import session 
from app.common.getautonum import GetAutonum
from datetime import datetime, timezone, timedelta
import utils.date_util
from utils.jsonwfc_object import JSONWFCObject
import resources.messages
from app.dto.draftsaveapi.draftsaveapi_dto import DraftsaveapiDto
from utils.save_data_check_utils import SaveDataCheckUtil
import utils.string_util




class DraftsaveapiService :

	#	# 
	# 報告書新規下書き保存
	# @param Entity
	# @param jsonObj
	# @throws Exception
	#
	def draftsaveapi(self,draftsaveapi_dto,jsonObj) :
			
		#GeniusClientScript 1315
		HOUKOKUSHOKOUMOKUISSHIKI = draftsaveapi_dto.houkokushokoumokuisshiki#GeninusClientScript 1318
		OK = utils.string_util.changeNullToBlank(utils.string_util.escapeSQLTags(utils.string_util.changeNullToBlank(draftsaveapi_dto.OK))) #GeniusSpringUtil 565
		#UltimateGeniuBean 115
		utils.config.global_log.debug(str(threading.current_thread().native_id)+ ": start")
		try :
			#報告書新規下書き保存_DRAFTSAVEAPI_(API)
			
			#「項目処理」（共通関数:DRAFTSAVEAPI）,パラメータは（報告書項目一式）
			
			#以下の処理を行う。
			
			#方法:POST/EV_DRAFT_SAVE.do（Content-Type:application/json）。op_id=form_new.draft
			
			#入力JSON:報告書項目一式
			
			#項目処理【下書き保存】:Toastのみ。DB未保存
			
			#trn_reportにstatus=draftで保存しJSON「OK」「c」「report_id」を返す。
			return OK
			#処理が成功した場合,JSON「OK」に「/manual-input/{id}/edit」,「c」に「下書き保存しました」を設定する。
			#GeniusClientScript 983
			if  == utils.string_util.changeStringToDouble(成功した) : #GeniusConditionParam 201 : #GeniusContion 823
				#GeniusConditionParam 201 : #GeniusContion 823
				#処理が失敗した場合,JSON「e」にエラーメッセージを設定し処理終了。
				#GeniusClientScript 983
				if  == utils.string_util.changeStringToDouble(失敗した) : #GeniusConditionParam 201 : #GeniusContion 823
					#GeniusConditionParam 201 : #GeniusContion 823
					#処理終了。
					#GeniusClientScript 1196
					pass
		except Exception as e:
			utils.config.global_log.error(e)
			raise
		utils.config.global_log.debug(str(threading.current_thread().native_id)+ ": end") 
		
			
	
	
