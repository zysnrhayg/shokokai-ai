#BasicService.vm
#make Service templete
import json
import utils.config
import threading
import utils.json_constant	
from flask import session 
from app.common.getautonum import GetAutonum
from datetime import datetime, timezone, timedelta
import utils.date_util
from utils.jsonwfc_object import JSONWFCObject
import resources.messages
from app.dao.api105_authenticateuser.api105_authenticateuser_dao import Api105AuthenticateuserDao
from app.dao.api107_inserttrusteddevice.api107_inserttrusteddevice_dao import Api107InserttrusteddeviceDao
from app.dto.api105_authenticateuser.api105_authenticateuser_dto import Api105AuthenticateuserDto
from app.dto.api107_inserttrusteddevice.api107_inserttrusteddevice_dto import Api107InserttrusteddeviceDto
from app.dto.verify2faapi.verify2faapi_dto import Verify2faapiDto
from utils.save_data_check_utils import SaveDataCheckUtil
import utils.string_util




class Verify2faapiService :

	#	# 
	# 二要素認証画面認証ボタン
	# @param Entity
	# @param jsonObj
	# @throws Exception
	#
	def verify2faapi(self,verify2faapi_dto,jsonObj) :
			
		#GeniusClientScript 1315
		CODE = verify2faapi_dto.code#GeninusClientScript 1318
		REMEMBER_DEVICE = verify2faapi_dto.rememberdevice#GeninusClientScript 1318
		PENDING_USER_ACCOUNT_ID = ""
		AUTH_RESULT= "" #GeniusVarItem 251
		api105_authenticateuser = Api105AuthenticateuserDto.dict_to_json({}) #CommonFunction 110
		api105_authenticateuserList = None #ResultGenerator 72
		#ResultGenerator 80
		SHUTOKUKENSUU = ""
		#_dto api105_authenticateuser_dto = None #ResultGenerator 119
		#ResultGenerator365
		USERACCOUNTID = ""
		PREFECTURECODE = ""
		SHOKOKAICD = ""
		USERID = ""
		SHOKUINKJ = ""
		PASSWORD = ""
		STATUS = ""
		TOTPSECRET = ""
		ISMFAENABLED = ""
		FAILEDLOGINCOUNT = ""
		LOCKEDUNTIL = ""
		TOTP_VALID = ""
		api107_inserttrusteddevice = Api107InserttrusteddeviceDto.dict_to_json({}) #CommonFunction 110
		AUTH_USER_ACCOUNT_ID= "" #GeniusVarItem 251
		AUTH_PREFECTURE_CODE= "" #GeniusVarItem 251
		AUTH_SHOKOKAI_CD= "" #GeniusVarItem 251
		AUTH_USER_ID= "" #GeniusVarItem 251
		AUTH_SHOKUIN_KJ= "" #GeniusVarItem 251
		#UltimateGeniuBean 115
		utils.config.global_log.debug(str(threading.current_thread().native_id)+ ": start")
		try :
			#二要素認証画面認証ボタン_Verify2faAPI_(API)
			
			#「項目処理」（共通関数:Verify2faAPI）,パラメータは（code,remember_device）
			
			#以下の処理を行う。
			
			#<pending_user_account_id>が空白の場合,以下の処理を行う。
			#GeniusClientScript 983
			if utils.string_util.isNullOrBlank(PENDING_USER_ACCOUNT_ID)   : #GeniusContion 823
				#GeniusContion 823
				#変数<auth_result>に"NG"を設定する。
				AUTH_RESULT = "NG" #GeniusVarItem 773
				#GeniusVarItem 773
				#処理終了。
				pass
				#GeniusClientScript 1207
			#関数「API105_AuthenticateUser」の「db_API105_AuthenticateUser」メソッドを行う,パラメータは「<pending_prefecture_code>,<pending_user_id>」,戻り値設定は「<user_account_id>=user_account_id,<prefecture_code>=prefecture_code,<shokokai_cd>=shokokai_cd,<user_id>=user_id,<shokuin_kj>=shokuin_kj,<password>=password,<status>=status,<totp_secret>=totp_secret,<is_mfa_enabled>=is_mfa_enabled,<failed_login_count>=failed_login_count,<locked_until>=locked_until」を設定する。
			
			# prefecture_code
			api105_authenticateuser.prefecturecode = <PENDING_PREFECTURE_CODE> #ArgumentGenerator 274
			#ArgumentGenerator 274
			
			# user_id
			api105_authenticateuser.userid = <PENDING_USER_ID> #ArgumentGenerator 274
			#ArgumentGenerator 274
			
			#ReulstGenerator 87
			api105_authenticateuserList = Api105AuthenticateuserDao().api105_authenticateuser(api105_authenticateuser)
			api105_authenticateuserlistVar = None #ResultGenerator 89
			#ResultGenerator 89
			if api105_authenticateuserList != None :
				api105_authenticateuserlistVar = api105_authenticateuserList.fetchall() if hasattr(api105_authenticateuserList, 'fetchall') else api105_authenticateuserList
			if api105_authenticateuserlistVar != None and len(api105_authenticateuserlistVar) > 0 :
				SHUTOKUKENSUU = str(len(api105_authenticateuserlistVar))
			# --LINE114 retrieved first value
			if api105_authenticateuserlistVar != None and len(api105_authenticateuserlistVar) > 0 :
				rec = api105_authenticateuserlistVar[0]
				USERACCOUNTID = utils.string_util.changeNullToBlank(utils.string_util.dict_get(rec, "user_account_id")) # ResultGenerator 385
				# ResultGenerator 385
				
				PREFECTURECODE = utils.string_util.changeNullToBlank(utils.string_util.dict_get(rec, "prefecture_code")) # ResultGenerator 385
				# ResultGenerator 385
				
				SHOKOKAICD = utils.string_util.changeNullToBlank(utils.string_util.dict_get(rec, "shokokai_cd")) # ResultGenerator 385
				# ResultGenerator 385
				
				USERID = utils.string_util.changeNullToBlank(utils.string_util.dict_get(rec, "user_id")) # ResultGenerator 385
				# ResultGenerator 385
				
				SHOKUINKJ = utils.string_util.changeNullToBlank(utils.string_util.dict_get(rec, "shokuin_kj")) # ResultGenerator 385
				# ResultGenerator 385
				
				PASSWORD = utils.string_util.changeNullToBlank(utils.string_util.dict_get(rec, "password")) # ResultGenerator 385
				# ResultGenerator 385
				
				STATUS = utils.string_util.changeNullToBlank(utils.string_util.dict_get(rec, "status")) # ResultGenerator 385
				# ResultGenerator 385
				
				TOTPSECRET = utils.string_util.changeNullToBlank(utils.string_util.dict_get(rec, "totp_secret")) # ResultGenerator 385
				# ResultGenerator 385
				
				ISMFAENABLED = utils.string_util.changeNullToBlank(utils.string_util.dict_get(rec, "is_mfa_enabled")) # ResultGenerator 385
				# ResultGenerator 385
				
				FAILEDLOGINCOUNT = utils.string_util.changeNullToBlank(utils.string_util.dict_get(rec, "failed_login_count")) # ResultGenerator 385
				# ResultGenerator 385
				
				LOCKEDUNTIL = utils.string_util.changeNullToBlank(utils.string_util.dict_get(rec, "locked_until")) # ResultGenerator 385
				# ResultGenerator 385
				
			#<user_account_id>が空白,または<user_account_id>が<pending_user_account_id>ではない場合,以下の処理を行う。
			#GeniusClientScript 983
			if utils.string_util.isNullOrBlank(USERACCOUNTID)   or USERACCOUNTID.replace(" ", "")!=PENDING_USER_ACCOUNT_ID : #GeniusContion 823
				#GeniusContion 823
				#変数<auth_result>に"NG"を設定する。
				AUTH_RESULT = "NG" #GeniusVarItem 773
				#GeniusVarItem 773
				#処理終了。
				pass
				#GeniusClientScript 1207
			#<status>が"1"ではない,または<locked_until>が設定されていてシステム日付が<locked_until>以前の場合,以下の処理を行う。
			#GeniusClientScript 983
			if STATUS.replace(" ", "")!="1" or LOCKEDUNTIL.replace(" ", "") == LOCKEDUNTIL : #GeniusContion 823
				#GeniusContion 823
				#変数<auth_result>に"NG"を設定する。
				AUTH_RESULT = "NG" #GeniusVarItem 773
				#GeniusVarItem 773
				#処理終了。
				pass
				#GeniusClientScript 1207
			#<is_mfa_enabled>が"true"ではない,または<totp_secret>が空白の場合,以下の処理を行う。
			#GeniusClientScript 983
			if ISMFAENABLED.replace(" ", "")!="true" or utils.string_util.isNullOrBlank(TOTPSECRET)   : #GeniusContion 823
				#GeniusContion 823
				#変数<auth_result>に"NG"を設定する。
				AUTH_RESULT = "NG" #GeniusVarItem 773
				#GeniusVarItem 773
				#処理終了。
				pass
				#GeniusClientScript 1207
			#<totp_valid>が"false"の場合,以下の処理を行う。
			#GeniusClientScript 983
			if TOTP_VALID.replace(" ", "") == "false" : #GeniusContion 823
				#GeniusContion 823
				#変数<auth_result>に"NG"を設定する。
				AUTH_RESULT = "NG" #GeniusVarItem 773
				#GeniusVarItem 773
				#処理終了。
				pass
				#GeniusClientScript 1207
			#<remember_device>が"true"の場合,以下の処理を行う。
			#GeniusClientScript 983
			if REMEMBER_DEVICE.replace(" ", "") == "true" : #GeniusContion 823
				#GeniusContion 823
				#関数「API107_InsertTrustedDevice」の「db_API107_InsertTrustedDevice」メソッドを行う,パラメータは「<user_account_id>,<token_hash>,<expires_at>」。
				
				# user_account_id
				api107_inserttrusteddevice.useraccountid = USERACCOUNTID #ArgumentGenerator 274
				#ArgumentGenerator 274
				
				# token_hash
				api107_inserttrusteddevice.tokenhash = <TOKEN_HASH> #ArgumentGenerator 274
				#ArgumentGenerator 274
				
				# expires_at
				api107_inserttrusteddevice.expiresat = <EXPIRES_AT> #ArgumentGenerator 274
				#ArgumentGenerator 274
				
				Api107InserttrusteddeviceDao().api107_inserttrusteddevice(api107_inserttrusteddevice) #ResultGenerator 104
				#ResultGenerator 104
				#変数<auth_result>に"OK"を設定する。
				AUTH_RESULT = "OK" #GeniusVarItem 773
				#GeniusVarItem 773
				#変数<auth_user_account_id>に<user_account_id>を設定する。
				AUTH_USER_ACCOUNT_ID = USERACCOUNTID #GeniusVarItem 773
				#GeniusVarItem 773
				#変数<auth_prefecture_code>に<prefecture_code>を設定する。
				AUTH_PREFECTURE_CODE = PREFECTURECODE #GeniusVarItem 773
				#GeniusVarItem 773
				#変数<auth_shokokai_cd>に<shokokai_cd>を設定する。
				AUTH_SHOKOKAI_CD = SHOKOKAICD #GeniusVarItem 773
				#GeniusVarItem 773
				#変数<auth_user_id>に<user_id>を設定する。
				AUTH_USER_ID = USERID #GeniusVarItem 773
				#GeniusVarItem 773
				#変数<auth_shokuin_kj>に<shokuin_kj>を設定する。
				AUTH_SHOKUIN_KJ = SHOKUINKJ #GeniusVarItem 773
				#GeniusVarItem 773
				#処理終了。
				pass
				#GeniusClientScript 1207
			#処理終了。
			
		except Exception as e:
			utils.config.global_log.error(e)
			raise
		utils.config.global_log.debug(str(threading.current_thread().native_id)+ ": end") 
		
			
	
	
