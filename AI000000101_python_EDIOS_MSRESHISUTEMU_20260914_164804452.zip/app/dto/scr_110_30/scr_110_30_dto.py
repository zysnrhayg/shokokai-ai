#py_entity.vm make dto templete
from utils.base_entity import BaseEntity
from voluptuous import Schema, Required, Range,MultipleInvalid,Length,Match,ALLOW_EXTRA,All
import re
from  utils.datecheck_hiduke import DateCheckHiduke
from  utils.datecheck_hiduke_ny import DateCheckHidukeNeGaTu
from  utils.datecheck_hiduke_yd import DateCheckHidukeGeTuNiChi
from  utils.datecheck_hiduke_compare import DateCheckHidukeCompare
from  utils.range_check import RangeCheck
class Scr11030Dto(BaseEntity):
		
	def __init__(self,mode,actflg,triggerid,row,f6):
		super().__init__(mode,actflg,triggerid,row)
			#F6
		self.f6 = f6
	
	def dict_to_json(dict):
		return Scr11030Dto(dict.get("mode",""),dict.get("actflg",""),dict.get("triggerid",""),dict.get("row",""),dict.get("f6",""))
	
	
	
	schema = Schema({
	
	}, required=False,extra=ALLOW_EXTRA) 

	def voluptuous_data(self, voluptuous_data) : 
		return
