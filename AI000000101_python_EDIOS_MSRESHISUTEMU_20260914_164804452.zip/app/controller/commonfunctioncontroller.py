from flask import Blueprint, Flask, request, jsonify, redirect, url_for, render_template,session, Response
from flask_login import login_user, login_required, logout_user
import os
import json
import traceback
import utils.config
from utils.jsonwfc_object import JSONWFCObject
import utils.string_util
from utils.exception_util import ValidationError, NotFoundError, DBError
import resources.messages


from app.service.verify2fainitapi.verify2fainitapi_service import Verify2fainitapiService


#
# aiproposalgenerateapi - AI支援提案AI提案を生成 - サーバー関数
# @param aiproposalgenerateapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/aiproposalgenerateapi.do", methods=['POST'])

def aiproposalgenerateapi() :
	"""aiproposalgenerateapi - AI支援提案AI提案を生成 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	aiproposalgenerateapi_dto = AiproposalgenerateapiDto.dict_to_json(data)
	aiproposalgenerateapiVar_service = AiproposalgenerateapiService()

	aiproposalgenerateapiVar_service.aiproposalgenerateapi(aiproposalgenerateapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# aiproposalinitapi - AI支援提案画面初期表示 - サーバー関数
# @param aiproposalinitapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/aiproposalinitapi.do", methods=['POST'])

def aiproposalinitapi() :
	"""aiproposalinitapi - AI支援提案画面初期表示 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	aiproposalinitapi_dto = AiproposalinitapiDto.dict_to_json(data)
	aiproposalinitapiVar_service = AiproposalinitapiService()

	aiproposalinitapiVar_service.aiproposalinitapi(aiproposalinitapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# aiproposalregenerateapi - AI支援提案違う内容を見る - サーバー関数
# @param aiproposalregenerateapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/aiproposalregenerateapi.do", methods=['POST'])

def aiproposalregenerateapi() :
	"""aiproposalregenerateapi - AI支援提案違う内容を見る - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	aiproposalregenerateapi_dto = AiproposalregenerateapiDto.dict_to_json(data)
	aiproposalregenerateapiVar_service = AiproposalregenerateapiService()

	aiproposalregenerateapiVar_service.aiproposalregenerateapi(aiproposalregenerateapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# dashboardheatmapcelltoggleapi - ダッシュボード（全国連）ヒートマップセル除外トグル - サーバー関数
# @param dashboardheatmapcelltoggleapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/dashboardheatmapcelltoggleapi.do", methods=['POST'])

def dashboardheatmapcelltoggleapi() :
	"""dashboardheatmapcelltoggleapi - ダッシュボード（全国連）ヒートマップセル除外トグル - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	dashboardheatmapcelltoggleapi_dto = DashboardheatmapcelltoggleapiDto.dict_to_json(data)
	dashboardheatmapcelltoggleapiVar_service = DashboardheatmapcelltoggleapiService()

	dashboardheatmapcelltoggleapiVar_service.dashboardheatmapcelltoggleapi(dashboardheatmapcelltoggleapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# dashboardheatmapfilterapi - ダッシュボード（全国連）ヒートマップ絞込（地方／グループ） - サーバー関数
# @param dashboardheatmapfilterapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/dashboardheatmapfilterapi.do", methods=['POST'])

def dashboardheatmapfilterapi() :
	"""dashboardheatmapfilterapi - ダッシュボード（全国連）ヒートマップ絞込（地方／グループ） - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	dashboardheatmapfilterapi_dto = DashboardheatmapfilterapiDto.dict_to_json(data)
	dashboardheatmapfilterapiVar_service = DashboardheatmapfilterapiService()

	dashboardheatmapfilterapiVar_service.dashboardheatmapfilterapi(dashboardheatmapfilterapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# dashboardheatmappageapi - ダッシュボード（全国連）ヒートマップページ送り - サーバー関数
# @param dashboardheatmappageapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/dashboardheatmappageapi.do", methods=['POST'])

def dashboardheatmappageapi() :
	"""dashboardheatmappageapi - ダッシュボード（全国連）ヒートマップページ送り - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	dashboardheatmappageapi_dto = DashboardheatmappageapiDto.dict_to_json(data)
	dashboardheatmappageapiVar_service = DashboardheatmappageapiService()

	dashboardheatmappageapiVar_service.dashboardheatmappageapi(dashboardheatmappageapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# dashboardinitapi - ダッシュボード（商工会）ダッシュボードを開く（初期データ取 - サーバー関数
# @param dashboardinitapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/dashboardinitapi.do", methods=['POST'])

def dashboardinitapi() :
	"""dashboardinitapi - ダッシュボード（商工会）ダッシュボードを開く（初期データ取 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	dashboardinitapi_dto = DashboardinitapiDto.dict_to_json(data)
	dashboardinitapiVar_service = DashboardinitapiService()

	dashboardinitapiVar_service.dashboardinitapi(dashboardinitapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# draftsaveapi - 報告書新規下書き保存 - サーバー関数
# @param draftsaveapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/draftsaveapi.do", methods=['POST'])

def draftsaveapi() :
	"""draftsaveapi - 報告書新規下書き保存 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	draftsaveapi_dto = DraftsaveapiDto.dict_to_json(data)
	draftsaveapiVar_service = DraftsaveapiService()

	draftsaveapiVar_service.draftsaveapi(draftsaveapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# expertimportapi - 専門家派遣報告取込取り込む - サーバー関数
# @param expertimportapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/expertimportapi.do", methods=['POST'])

def expertimportapi() :
	"""expertimportapi - 専門家派遣報告取込取り込む - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	expertimportapi_dto = ExpertimportapiDto.dict_to_json(data)
	expertimportapiVar_service = ExpertimportapiService()

	expertimportapiVar_service.expertimportapi(expertimportapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# formeditinitapi - 報告書編集画面初期表示 - サーバー関数
# @param formeditinitapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/formeditinitapi.do", methods=['POST'])

def formeditinitapi() :
	"""formeditinitapi - 報告書編集画面初期表示 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	formeditinitapi_dto = FormeditinitapiDto.dict_to_json(data)
	formeditinitapiVar_service = FormeditinitapiService()

	formeditinitapiVar_service.formeditinitapi(formeditinitapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# formeditsaveapi - 報告書編集画面登録ボタン - サーバー関数
# @param formeditsaveapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/formeditsaveapi.do", methods=['POST'])

def formeditsaveapi() :
	"""formeditsaveapi - 報告書編集画面登録ボタン - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	formeditsaveapi_dto = FormeditsaveapiDto.dict_to_json(data)
	formeditsaveapiVar_service = FormeditsaveapiService()

	formeditsaveapiVar_service.formeditsaveapi(formeditsaveapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# formexportapi - 報告書新規帳票出力 - サーバー関数
# @param formexportapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/formexportapi.do", methods=['POST'])

def formexportapi() :
	"""formexportapi - 報告書新規帳票出力 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	formexportapi_dto = FormexportapiDto.dict_to_json(data)
	formexportapiVar_service = FormexportapiService()

	formexportapiVar_service.formexportapi(formexportapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# formnewinitapi - 報告書新規画面初期表示 - サーバー関数
# @param formnewinitapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/formnewinitapi.do", methods=['POST'])

def formnewinitapi() :
	"""formnewinitapi - 報告書新規画面初期表示 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	formnewinitapi_dto = FormnewinitapiDto.dict_to_json(data)
	formnewinitapiVar_service = FormnewinitapiService()

	formnewinitapiVar_service.formnewinitapi(formnewinitapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# formnewsaveapi - 報告書新規画面登録ボタン - サーバー関数
# @param formnewsaveapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/formnewsaveapi.do", methods=['POST'])

def formnewsaveapi() :
	"""formnewsaveapi - 報告書新規画面登録ボタン - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	formnewsaveapi_dto = FormnewsaveapiDto.dict_to_json(data)
	formnewsaveapiVar_service = FormnewsaveapiService()

	formnewsaveapiVar_service.formnewsaveapi(formnewsaveapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# knowledgesearchapi - AI支援提案ナレッジを検索 - サーバー関数
# @param knowledgesearchapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/knowledgesearchapi.do", methods=['POST'])

def knowledgesearchapi() :
	"""knowledgesearchapi - AI支援提案ナレッジを検索 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	knowledgesearchapi_dto = KnowledgesearchapiDto.dict_to_json(data)
	knowledgesearchapiVar_service = KnowledgesearchapiService()

	knowledgesearchapiVar_service.knowledgesearchapi(knowledgesearchapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# loginapi - ログイン画面ログインボタン - サーバー関数
# @param loginapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/loginapi.do", methods=['POST'])

def loginapi() :
	"""loginapi - ログイン画面ログインボタン - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	loginapi_dto = LoginapiDto.dict_to_json(data)
	loginapiVar_service = LoginapiService()

	loginapiVar_service.loginapi(loginapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# logininitapi - ログイン画面 - サーバー関数
# @param logininitapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/logininitapi.do", methods=['POST'])

def logininitapi() :
	"""logininitapi - ログイン画面 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	logininitapi_dto = LogininitapiDto.dict_to_json(data)
	logininitapiVar_service = LogininitapiService()

	logininitapiVar_service.logininitapi(logininitapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# logoutapi - ログアウト - サーバー関数
# @param logoutapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/logoutapi.do", methods=['POST'])

def logoutapi() :
	"""logoutapi - ログアウト - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	logoutapi_dto = LogoutapiDto.dict_to_json(data)
	logoutapiVar_service = LogoutapiService()

	logoutapiVar_service.logoutapi(logoutapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# monthlyexportapi - 月次報告月次帳票出力 - サーバー関数
# @param monthlyexportapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/monthlyexportapi.do", methods=['POST'])

def monthlyexportapi() :
	"""monthlyexportapi - 月次報告月次帳票出力 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	monthlyexportapi_dto = MonthlyexportapiDto.dict_to_json(data)
	monthlyexportapiVar_service = MonthlyexportapiService()

	monthlyexportapiVar_service.monthlyexportapi(monthlyexportapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# monthlyfiscalyearapi - 月次報告年度切替 - サーバー関数
# @param monthlyfiscalyearapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/monthlyfiscalyearapi.do", methods=['POST'])

def monthlyfiscalyearapi() :
	"""monthlyfiscalyearapi - 月次報告年度切替 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	monthlyfiscalyearapi_dto = MonthlyfiscalyearapiDto.dict_to_json(data)
	monthlyfiscalyearapiVar_service = MonthlyfiscalyearapiService()

	monthlyfiscalyearapiVar_service.monthlyfiscalyearapi(monthlyfiscalyearapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# monthlyinitapi - 月次報告画面初期表示 - サーバー関数
# @param monthlyinitapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/monthlyinitapi.do", methods=['POST'])

def monthlyinitapi() :
	"""monthlyinitapi - 月次報告画面初期表示 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	monthlyinitapi_dto = MonthlyinitapiDto.dict_to_json(data)
	monthlyinitapiVar_service = MonthlyinitapiService()

	monthlyinitapiVar_service.monthlyinitapi(monthlyinitapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# reportdetailinitapi - 報告書詳細画面初期表示 - サーバー関数
# @param reportdetailinitapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/reportdetailinitapi.do", methods=['POST'])

def reportdetailinitapi() :
	"""reportdetailinitapi - 報告書詳細画面初期表示 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	reportdetailinitapi_dto = ReportdetailinitapiDto.dict_to_json(data)
	reportdetailinitapiVar_service = ReportdetailinitapiService()

	reportdetailinitapiVar_service.reportdetailinitapi(reportdetailinitapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# reportscsvexportapi - 報告書一覧（様式F）CSV出力 - サーバー関数
# @param reportscsvexportapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/reportscsvexportapi.do", methods=['POST'])

def reportscsvexportapi() :
	"""reportscsvexportapi - 報告書一覧（様式F）CSV出力 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	reportscsvexportapi_dto = ReportscsvexportapiDto.dict_to_json(data)
	reportscsvexportapiVar_service = ReportscsvexportapiService()

	reportscsvexportapiVar_service.reportscsvexportapi(reportscsvexportapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# reportsinitapi - 報告書一覧画面初期表示 - サーバー関数
# @param reportsinitapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/reportsinitapi.do", methods=['POST'])

def reportsinitapi() :
	"""reportsinitapi - 報告書一覧画面初期表示 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	reportsinitapi_dto = ReportsinitapiDto.dict_to_json(data)
	reportsinitapiVar_service = ReportsinitapiService()

	reportsinitapiVar_service.reportsinitapi(reportsinitapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# reportssearchapi - 報告書一覧画面初期表示 - サーバー関数
# @param reportssearchapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/reportssearchapi.do", methods=['POST'])

def reportssearchapi() :
	"""reportssearchapi - 報告書一覧画面初期表示 - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	reportssearchapi_dto = ReportssearchapiDto.dict_to_json(data)
	reportssearchapiVar_service = ReportssearchapiService()

	reportssearchapiVar_service.reportssearchapi(reportssearchapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# verify2faapi - 二要素認証画面認証ボタン - サーバー関数
# @param verify2faapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/verify2faapi.do", methods=['POST'])

def verify2faapi() :
	"""verify2faapi - 二要素認証画面認証ボタン - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	verify2faapi_dto = Verify2faapiDto.dict_to_json(data)
	verify2faapiVar_service = Verify2faapiService()

	verify2faapiVar_service.verify2faapi(verify2faapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



#
# verify2fainitapi - 二段階認証画面画面を開く - サーバー関数
# @param verify2fainitapi_dto
# @param result
# @throws Exception
#

@${SpringBootPageBucket.pageMngId}_route.route("/verify2fainitapi.do", methods=['POST'])

def verify2fainitapi() :
	"""verify2fainitapi - 二段階認証画面画面を開く - サーバー関数"""

	data = request.get_json()
	jsonObj = JSONWFCObject()

	# validate parameter 371

	
#UnitedControllerBuilder 963

	verify2fainitapi_dto = Verify2fainitapiDto.dict_to_json(data)
	verify2fainitapiVar_service = Verify2fainitapiService()

	verify2fainitapiVar_service.verify2fainitapi(verify2fainitapi_dto, jsonObj)
	
	return jsonObj.toJsonString()



